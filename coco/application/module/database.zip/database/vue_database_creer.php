﻿
        <h1>Création de la BDD</h1>
		<pre>
        <?php        
		echo $sql;                
        ?>
		</pre>
